import React from 'react';

function Header() {
  return (
    <header style={{ backgroundColor: '#e67e22', padding: '15px', textAlign: 'center' }}>
      <img 
        src="/images/fpt.png"  
        style={{ height: '300px'}} 
      />
      <div style={{ marginTop: '10px', color: '#fff' }}>Home About Contact</div>
    </header>
  );
}

export default Header;