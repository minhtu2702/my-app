import React from 'react';

function Footer() {
  return (
    <footer style={{ backgroundColor: 'gold', textAlign: 'center', padding: '10px' }}>
      <p>© 2023 Website. All rights reserved.</p>
    </footer>
  );
}

export default Footer;