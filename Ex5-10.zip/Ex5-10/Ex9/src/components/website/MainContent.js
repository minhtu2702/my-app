import React from 'react';

function MainContent() {
  return (
    <main style={{ textAlign: 'center', padding: '20px' }}>
      <h3>About</h3>
      <p>This is the about section of the website.</p>
      <h3>Contact</h3>
      <p>For any inquiries, please contact us at example@example.com.</p>
    </main>
  );
}

export default MainContent;