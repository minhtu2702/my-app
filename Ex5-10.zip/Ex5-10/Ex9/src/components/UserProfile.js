import React from 'react';

function UserProfile() {
  return (
    <div style={{ border: '1px solid #000', padding: '10px' }}>
      <h2>Hoai Nguyen - FPT DaNang</h2>
      <p>Moblie: 0982827763</p>
    </div>
  );
}

export default UserProfile;