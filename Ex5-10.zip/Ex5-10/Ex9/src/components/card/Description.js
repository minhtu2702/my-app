import React from 'react';

function Description({ text }) {
  return <p style={{ color: 'gray', margin: 0 }}>{text}</p>;
}

export default Description;