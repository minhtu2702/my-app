import React from 'react';
import Title from './Title';
import Description from './Description';
import Image from './Image';

function SimpleCard({ item }) {
  return (
    <div style={{ display: 'flex', border: '2px solid blue', width: '300px', padding: '5px' }}>
      <div style={{ backgroundColor: 'yellow', padding: '5px' }}>
        <Image url={item.imageUrl} />
      </div>
      <div style={{ border: '1px solid orange', marginLeft: '5px', padding: '5px', flex: 1 }}>
        <Title text={item.title} />
        <Description text={item.description} />
      </div>
    </div>
  );
}

export default SimpleCard;