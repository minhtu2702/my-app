import React from 'react';

function Title({ text }) {
  return <h3 style={{ color: 'orange', margin: 0 }}>{text}</h3>;
}

export default Title;