import React from 'react';

function Image({ url }) {
  return <img src={url} alt="img" style={{ width: '80px', height: '80px' }} />;
}

export default Image;