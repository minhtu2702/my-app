import React from 'react';
import UserProfile from './components/UserProfile';
import HelloWorld from './components/HelloWorld';
import Counter from './components/Counter';
import SimpleCard from './components/card/SimpleCard';
import SimpleWebsite from './components/website/SimpleWebsite';

function App() {
  const cardData = {
    title: 'Hoai Nguyen - FPT Da Nang',
    description: 'Moblie: 0982827763',
    imageUrl: '/images/fpt.png'
  };

  return (
    <div style={{ padding: '20px' }}>
      <h2>Ex 1: User Profile</h2>
      <UserProfile />
      <hr />

      <h2>Ex 2: Hello World</h2>
      <HelloWorld />
      <hr />

      <h2>Ex 3: Counter</h2>
      <Counter />
      <hr />

      <h2>Ex 4: Simple Card</h2>
      <SimpleCard item={cardData} />
      <hr />

      <h2>Ex 5: Simple Website</h2>
      <SimpleWebsite />
    </div>
  );
}

export default App;