import { useState } from 'react';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';

function BookingForm() {
  const [formData, setFormData] = useState({ name: '', email: '', service: '', comment: '' });

  const handleChange = (e) => setFormData({ ...formData, [e.target.name]: e.target.value });

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Booking submitted:', formData);
    alert('Thank you, we have received your booking request!');
  };

  return (
    <section className="booking-section" id="contact">
      <Container>
        <h2 className="booking-heading">Book Your Table</h2>
        <Form onSubmit={handleSubmit}>
          <Row className="g-3 mb-3">
            <Col md={4}>
              <Form.Control type="text" name="name" placeholder="Your Name *" required value={formData.name} onChange={handleChange} />
            </Col>
            <Col md={4}>
              <Form.Control type="email" name="email" placeholder="Your Email *" required value={formData.email} onChange={handleChange} />
            </Col>
            <Col md={4}>
              <Form.Select name="service" value={formData.service} onChange={handleChange}>
                <option value="">Select a Service</option>
                <option value="dine-in">Dine In</option>
                <option value="takeaway">Takeaway</option>
                <option value="delivery">Delivery</option>
              </Form.Select>
            </Col>
          </Row>
          <Row className="mb-3">
            <Col>
              <Form.Control as="textarea" rows={4} name="comment" placeholder="Please write your comment" value={formData.comment} onChange={handleChange} />
            </Col>
          </Row>
          <Button type="submit" variant="warning">Send Message</Button>
        </Form>
      </Container>
    </section>
  );
}

export default BookingForm;