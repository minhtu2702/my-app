import React, { useState } from 'react'
import { Button, Card } from 'react-bootstrap'

function PizzaCard({ pizza }) {
  
  const [isSelected, setIsSelected] = useState(false);

  const handleBuy = () => {
    setIsSelected(!isSelected); 
  };

  return (
    <div>
      <Card bg="white" text="dark">
        <div style={{ width: '100%', height: '200px', overflow: 'hidden' }}>
          <Card.Img 
            variant="top" 
            src={pizza?.image} 
            style={{ width: '100%', height: '100%', objectFit: 'cover' }}
          />
        </div>
  
        <Card.Body>
          <Card.Title>{pizza?.name}</Card.Title>
          <Card.Text>
            Price: {pizza?.price}
          </Card.Text>
          <Button 
            onClick={handleBuy}
            style={{ width: '100%' }} 
            className={isSelected ? "bg-success text-white border-0" : "bg-dark text-white border-0"}
          >
            {isSelected ? "SELECTED" : "BUY"}
          </Button>
        </Card.Body>
      </Card>
    </div>
  )
}

export default PizzaCard