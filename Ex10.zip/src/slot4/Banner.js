import Card from 'react-bootstrap/Card';

function Banner() {
  return (
    <Card className="bg-dark text-white border-0" style={{ height: '60vh', overflow: 'hidden' }}>
      <Card.Img 
        src="https://images.unsplash.com/photo-1513104890138-7c749659a591" 
        alt="Card image" 
        className="w-100 h-100"
        style={{ objectFit: 'cover' }}
      />
      <Card.ImgOverlay className="d-flex flex-column justify-content-end align-items-center text-center pb-4">
        <Card.Title as="h2" className="fw-bold">Pizza House</Card.Title>
        <Card.Text>
        Hot, crispy, and baked with love—your ultimate pizza destination!
        </Card.Text>
      </Card.ImgOverlay>
    </Card>
  );
}

export default Banner;