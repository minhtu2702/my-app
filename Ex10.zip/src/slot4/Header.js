import { Form, Button } from 'react-bootstrap';
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import { CiSearch } from "react-icons/ci";

function Header() {
    return (
        <Navbar expand="lg" bg="dark" data-bs-theme="dark">
            <Container>
                <Navbar.Brand href="#home" className='fw-bold'>
                    Pizza House
                </Navbar.Brand>
                <Navbar.Toggle aria-controls="basic-navbar-nav" />
                <Navbar.Collapse id="basic-navbar-nav">
                    <Nav className="me-auto">
                        <Nav.Link href="#home">Home</Nav.Link>
                        <Nav.Link href="#about-us">About Us</Nav.Link>
                        <Nav.Link href="#contact">Contact</Nav.Link>
                    </Nav>
                    <Form className="d-flex gap-2">
                        <Form.Control
                            type="search"
                            placeholder="Search"
                            aria-label="Search"
                            className="bg-white text-dark"
                        />
                        <Button type="submit" variant="danger">
                        <CiSearch />
                        </Button>
                    </Form>
                </Navbar.Collapse>


            </Container>
        </Navbar >
    );
}

export default Header;