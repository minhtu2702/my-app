import { Col, Container, Row } from "react-bootstrap";
//import StudentCard from "./slot4/StudentCard";
import Header from "./slot4/Header";
import Banner from "./slot4/Banner";
import PizzaCard from "./slot4/PizzaCard";
import BookingForm from "./slot4/BookingForm";

function App() {
  const pizzas = [
    {
      id: 1,
      name: "Margherita Pizza",
      price: 159000,
      image: "https://images.unsplash.com/photo-1604382354936-07c5d9983bd3"
    },
    {
      id: 2,
      name: "Pepperoni Pizza",
      price: 189000,
      image: "https://images.unsplash.com/photo-1628840042765-356cda07504e"
    },
    {
      id: 3,
      name: "Seafood Deluxe",
      price: 219000,
      image: "https://images.unsplash.com/photo-1565299624946-b28f40a0ae38"
    },
    {
      id: 4,
      name: "Hawaiian Pizza",
      price: 179000,
      image: "https://images.unsplash.com/photo-1534308983496-4fabb1a015ee"
    }
  ];

  return (
    <> 
    <div data-bs-theme="dark" className="bg-dark text-light min-vh-100">
      <Header />
      <Banner />
      <h3>Our Menu</h3>
      <Container className="mt-5">
        <Row>
          {pizzas.map((pizza) => (
            <Col md={3} key={pizza.id}>
              <PizzaCard pizza={pizza} />
            </Col>
          ))}
        </Row>
      </Container>
      <BookingForm />
      </div>
    </>
  );
}

export default App;