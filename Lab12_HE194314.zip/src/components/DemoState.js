import React, { useState } from 'react'

function DemoState() {
 // const [name, setName] = useState("");
  const [user, setUser] = useState({
    name: "Tu",
    age: 20,
  });
  const changeAge = () =>{
    setUser({
        ...user,
        age:user.age + 2,
    })
  }
  return (
  <div>
    <p>Name: {user.name}</p> 
    <p>Age: {user.age}</p>
    <button onClick={changeAge}>Change Age</button>
  </div>
    
  )
}

export default DemoState;