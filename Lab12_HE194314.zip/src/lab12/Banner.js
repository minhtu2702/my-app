import Card from 'react-bootstrap/Card';

function Banner() {
  return (
    <Card className="bg-dark text-white border-0" style={{ height: '60vh', overflow: 'hidden' }}>
      <Card.Img 
        src="/images/banner1.jpg" 
        alt="Card image" 
        className="w-100 h-100"
        style={{ objectFit: 'cover' }}
      />
      <Card.ImgOverlay className="d-flex flex-column align-items-center text-center pb-4">
        <Card.Title as="h1" className="fw-bold">PROMOTIONAL BANNER</Card.Title>
        
      </Card.ImgOverlay>
    </Card>
  );
}

export default Banner;