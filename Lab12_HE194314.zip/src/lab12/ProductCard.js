import React, { useState } from 'react'
import { Button, Card } from 'react-bootstrap'

function ProductCard({ shopping }) {
  
const [isSelected, setIsSelected] = useState(false);

  const handleAddCart = () => {
    setIsSelected(!isSelected); 
  };
  return (
    <div>
      <Card bg="white" text="dark">
        <div style={{ width: '100%', height: '200px', overflow: 'hidden' }}>
          <Card.Img 
            variant="top" 
            src={shopping?.image} 
            style={{ width: '100%', height: '100%', objectFit: 'cover' }}
          />
        </div>
        <Card.Body>
          <Card.Title>{shopping?.name}</Card.Title>
          <Card.Text>
            {shopping?.price} VND 
          </Card.Text>
          <Card.Text>
            {shopping?.status}
          </Card.Text>
          <Button 
            onClick={handleAddCart}
            style={{ width: '100%' }} 
            className={isSelected ? "bg-success text-white border-0" : "bg-dark text-white border-0"}
          >
            {isSelected ? "Added" : "Add Cart"}
          </Button>
        </Card.Body>
      </Card>
    </div>
  )
}

export default ProductCard