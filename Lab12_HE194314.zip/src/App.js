import { Col, Container, Row } from "react-bootstrap";
import Header from "./lab12/Header";
import Banner from "./lab12/Banner";
import ProductCard from "./lab12/ProductCard";
import products from "./data/products";
function App() {
  
  return (
    <> 
    <div data-bs-theme="dark" className="bg-dark text-light min-vh-100">
      <Header />
      <Banner />
      <h3 className="d-flex flex-column align-items-center text-center pb-4">PRODUCTS</h3>
      <Container className="mt-5">
        <Row>
          {products.map((shopping) => (
            <Col md={4} key={shopping.id}>
              <ProductCard shopping={shopping} />
            </Col>
          ))}
        </Row>
      </Container>
      </div>
    </>
  );
}

export default App;